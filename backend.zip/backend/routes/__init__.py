# routes/__init__.py
from flask import Blueprint

