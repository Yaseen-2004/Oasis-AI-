import torch.nn as nn
import torch.nn.functional as F
from .backbone import EmbeddingNet

class SiameseNetwork(nn.Module):
    """
    Siamese Network that compares two medical images and outputs similarity score.
    """
    def __init__(self, embedding_dim=128, pretrained=True):
        super(SiameseNetwork, self).__init__()
        self.embedding_net = EmbeddingNet(embedding_dim=embedding_dim, pretrained=pretrained)

    def forward(self, x1, x2):
        emb1 = self.embedding_net(x1)
        emb2 = self.embedding_net(x2)
        # cosine similarity between embeddings
        similarity = F.cosine_similarity(emb1, emb2)
        return similarity
