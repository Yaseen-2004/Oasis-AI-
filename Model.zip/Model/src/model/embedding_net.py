import torch
import torch.nn as nn

# -------------------------------
# Embedding Network (already built earlier)
# -------------------------------
class EmbeddingNet(nn.Module):
    def __init__(self, embedding_dim=128):
        super(EmbeddingNet, self).__init__()
        self.convnet = nn.Sequential(
            nn.Conv2d(3, 32, 5),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 5),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(64, 128, 5),
            nn.ReLU(),
            nn.MaxPool2d(2)
        )
        self.fc = nn.Sequential(
            nn.Linear(128 * 24 * 24, 512),
            nn.ReLU(),
            nn.Linear(512, embedding_dim)
        )

    def forward(self, x):
        x = self.convnet(x)
        x = x.view(x.size(0), -1)   # flatten
        x = self.fc(x)
        return x


# -------------------------------
# Classifier Network
# -------------------------------
class ClassifierNet(nn.Module):
    def __init__(self, embedding_dim=128, num_classes=6):
        super(ClassifierNet, self).__init__()
        self.embedding = EmbeddingNet(embedding_dim=embedding_dim)
        self.classifier = nn.Linear(embedding_dim, num_classes)

    def forward(self, x):
        x = self.embedding(x)       # get embeddings
        x = self.classifier(x)      # classify
        return x


# -------------------------------
# Quick Test
# -------------------------------
if __name__ == "__main__":
    # Assume input image size = 224x224 RGB
    model = ClassifierNet(embedding_dim=128, num_classes=6)
    print(model)

    dummy_input = torch.randn(4, 3, 224, 224)  # batch of 4 images
    output = model(dummy_input)

    print("Output shape:", output.shape)  # should be [4, 6]