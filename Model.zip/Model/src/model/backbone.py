import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

class EmbeddingNet(nn.Module):
    """
    Embedding network using ResNet18 backbone.
    Converts input medical image into a fixed-size feature vector.
    """
    def __init__(self, embedding_dim=128, pretrained=True):
        super(EmbeddingNet, self).__init__()
        base_model = models.resnet18(pretrained=pretrained)
        # Remove final classifier (fc)
        modules = list(base_model.children())[:-1]  
        self.feature_extractor = nn.Sequential(*modules)
        self.fc = nn.Linear(base_model.fc.in_features, embedding_dim)

    def forward(self, x):
        x = self.feature_extractor(x)   # [batch, 512, 1, 1]
        x = x.view(x.size(0), -1)       # flatten
        x = self.fc(x)                  # [batch, embedding_dim]
        x = F.normalize(x, p=2, dim=1)  # L2-normalize
        return x
